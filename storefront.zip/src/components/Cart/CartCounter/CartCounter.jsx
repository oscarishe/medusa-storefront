import { useStore } from '@nanostores/react';
import { cartItems } from '../../../store/cartProductsStore';
export const CartCounter = () => {
    const $cartCounter = useStore(cartItems);
    return (
        <div className="cart__counter">{$cartCounter.length}</div>
    )
}

export default CartCounter;