import { defineConfig } from 'astro/config';
import node from '@astrojs/node';

import react from "@astrojs/react";

// https://astro.build/config
export default defineConfig({
  integrations: [react()],
  server: { port: 8080 },
  output: 'server',
  adapter: node({
    mode: 'standalone'
  }),
});